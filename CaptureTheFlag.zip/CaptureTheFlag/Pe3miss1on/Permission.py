import base64

# Base64-encoded flag
encoded_flag = "RkxBR3tDaE0wRF9BY2Myc3NfR3JhbjFlZH0gCg=="

# Decode from base64
decoded_bytes = base64.b64decode(encoded_flag)
decoded_flag = decoded_bytes.decode('utf-8').strip()

print("Decoded Flag:", decoded_flag)
